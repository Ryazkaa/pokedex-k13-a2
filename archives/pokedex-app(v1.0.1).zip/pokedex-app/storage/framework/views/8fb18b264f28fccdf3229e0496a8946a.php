<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="color-scheme" content="dark">
    <meta name="theme-color" content="#0f1923">
    <title><?php echo $__env->yieldContent('title', 'Pokedex'); ?></title>
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('favicon.svg')); ?>?v=<?php echo e(filemtime(public_path('favicon.svg'))); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.svg')); ?>?v=<?php echo e(filemtime(public_path('favicon.svg'))); ?>">

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link rel="stylesheet" href="https://fonts.bunny.net/css?family=chakra-petch:600,700|jetbrains-mono:500,600,700|plus-jakarta-sans:400,500,600,700,800&display=swap">
    <link rel="preconnect" href="https://raw.githubusercontent.com">
    <?php echo $__env->yieldPushContent('head'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('css/pokedex.css')); ?>?v=<?php echo e(filemtime(public_path('css/pokedex.css'))); ?>">
</head>
<body>
    
    <div class="page-bg" aria-hidden="true"></div>

    <a class="skip-link" href="#search">Langsung ke tabel Pokédex</a>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH E:\Institut Pertanian Bogor\Semester 3\4 - Kamis - Pemrograman Web\Pertemuan 11\Pokedex - Tugas Individu\pokedex-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>