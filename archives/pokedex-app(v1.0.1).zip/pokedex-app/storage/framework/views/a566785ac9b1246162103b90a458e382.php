

<?php $__env->startSection('title', 'Pokedex'); ?>

<?php
    $typeMeta = collect(config('pokedex.types'))->map(function ($meta) {
        $meta['icon'] = asset($meta['icon']);
        return $meta;
    })->all();
    $regionMeta = config('pokedex.regions');
    $total = $pokemons->count();
    $hero = $featured->first();
    $clientPayload = [
        'pokemons' => $pokemons->map->toClient()->values(),
        'featured' => $featured->pluck('nomor_index')->values(),
        'total' => $total,
        'types' => $typeMeta,
        'regions' => $regionMeta,
        'genCounts' => $pokemons->countBy('gen_roman'),
        'newIds' => $importResult['new_ids'] ?? [],
    ];
?>

<?php $__env->startPush('head'); ?>
    <?php if($hero): ?>
        <link rel="preload" as="image" href="<?php echo e($hero->artwork_url); ?>" fetchpriority="high">
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('pokedex.partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('pokedex.partials.menu-drawer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main id="main" class="shell">
        <?php echo $__env->make('pokedex.partials.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('pokedex.partials.bento', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('pokedex.partials.import-alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('pokedex.partials.table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </main>

    <footer class="site-footer shell">
        <p>Pokédex - Kelompok 13 - Kelas A / A2</p>
        <p>Laravel <?php echo e(app()->version()); ?> · PhpSpreadsheet · Artwork dari PokeAPI</p>
    </footer>

    <?php echo $__env->make('pokedex.partials.showcase-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div id="envelopeOverlay" class="env-overlay" aria-hidden="true" hidden>
        <div class="env-stage">
            <div class="env-box" id="envBox">
                
                <div class="env-back"></div>

                
                <div class="env-letter">
                    <div class="env-letter__badge">.XLSX</div>
                    <div class="env-letter__lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <p class="env-letter__title">Pokedex Library</p>
                </div>

                
                <div class="env-pocket"></div>

                
                <div class="env-flap"></div>

                
                <div class="env-seal">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 12.5 4 4L18 8.5" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </div>
            </div>
            <p class="env-caption">Mengemas &amp; Mengunduh <strong>.xlsx</strong>…</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        window.POKEDEX = <?php echo json_encode($clientPayload, 15, 512) ?>;
    </script>
    <script src="<?php echo e(asset('js/pokedex.js')); ?>?v=<?php echo e(filemtime(public_path('js/pokedex.js'))); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Institut Pertanian Bogor\Semester 3\4 - Kamis - Pemrograman Web\Pertemuan 999\src\resources\views/pokedex/index.blade.php ENDPATH**/ ?>