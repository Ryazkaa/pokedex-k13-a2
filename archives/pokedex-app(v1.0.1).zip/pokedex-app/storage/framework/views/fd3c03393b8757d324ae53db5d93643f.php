
<?php
    $funFacts = collect(config('pokedex.fun_facts', []))->shuffle()->values();
?>

<section id="home" class="hero section" aria-roledescription="carousel" aria-label="Fun Facts Dunia Pokémon">
    <div class="hero__deck" id="heroDeck">
        <?php $__currentLoopData = $funFacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $fact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $artUrl = 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/' . $fact['art_num'] . '.png';
                $previewText = \Illuminate\Support\Str::limit($fact['desc'], 148, '');
            ?>
            <article class="hero__slide <?php echo e($i === 0 ? 'is-active' : ''); ?>"
                     data-slot="<?php echo e($i); ?>"
                     data-depth="<?php echo e(min($i, 4)); ?>"
                     data-fact-topic="<?php echo e($fact['topic']); ?>"
                     data-fact-title="<?php echo e($fact['title']); ?>"
                     data-fact-desc="<?php echo e($fact['desc']); ?>"
                     data-fact-category="<?php echo e($fact['category']); ?>"
                     data-fact-source="<?php echo e($fact['source']); ?>"
                     data-fact-art="<?php echo e($artUrl); ?>"
                     data-fact-name="<?php echo e($fact['art_name']); ?>"
                     data-fact-no="#<?php echo e(str_pad((string) $fact['art_num'], 4, '0', STR_PAD_LEFT)); ?>"
                     aria-roledescription="slide"
                     aria-label="Fun Fact <?php echo e($i + 1); ?> dari <?php echo e($funFacts->count()); ?>"
                     <?php if($i !== 0): ?> inert <?php endif; ?>>
                <div class="hero__card-bg" aria-hidden="true"></div>
                <div class="hero__text">
                    <p class="hero__eyebrow">Fun Fact · <?php echo e($fact['topic']); ?></p>
                    <h2 class="hero__title hero__title--fact"><?php echo e($fact['title']); ?></h2>
                    <p class="hero__lore">
                        <span><?php echo e($previewText); ?>…</span>
                        <button type="button"
                                class="hero__readmore"
                                data-open-fact="<?php echo e($i); ?>"
                                aria-label="Baca selengkapnya tentang <?php echo e($fact['title']); ?>">
                            (selengkapnya...)
                        </button>
                    </p>
                    <div class="hero__meta">
                        <span class="fact-tag"><?php echo e($fact['category']); ?></span>
                        <span class="hero__gen"><?php echo e($fact['source']); ?></span>
                    </div>
                </div>
                <img class="hero__art"
                     src="<?php echo e($artUrl); ?>"
                     alt="<?php echo e($fact['art_name']); ?>"
                     width="440" height="440"
                     <?php if($i === 0): ?> fetchpriority="high" <?php else: ?> loading="lazy" <?php endif; ?>>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($funFacts->count() > 1): ?>
            <div class="hero__controls">
                <div class="hero__nav-btns" role="group" aria-label="Navigasi Fun Fact">
                    <button type="button" class="hero__deck-btn" id="heroPrev" aria-label="Fun Fact sebelumnya" title="Sebelumnya">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 6-6 6 6 6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </button>
                    <button type="button" class="hero__deck-btn" id="heroNext" aria-label="Fun Fact berikutnya" title="Berikutnya">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 6 6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </button>
                </div>
            </div>
        <?php endif; ?>
    </div>

    
    <dialog id="factModal" class="fact-modal" closedby="any" aria-labelledby="factModalTitle">
        <div class="fact-modal__card">
            <div class="fact-modal__banner fact-cascade" style="--cascade-i: 0">
                <div class="fact-modal__banner-meta">
                    <p class="fact-modal__eyebrow" id="factModalTopic">Fun Fact</p>
                    <span class="fact-modal__poke-pill" id="factModalPoke">#0001</span>
                </div>
                <button type="button" class="fact-modal__close" data-close-dialog aria-label="Tutup Fun Fact">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/></svg>
                </button>
                <img class="fact-modal__art" id="factModalArt" src="" alt="" width="150" height="150">
            </div>

            <div class="fact-modal__body">
                <div class="fact-modal__tags fact-cascade" style="--cascade-i: 1">
                    <span class="fact-tag" id="factModalCategory">Kategori</span>
                    <span class="hero__gen" id="factModalSource">Sumber</span>
                </div>

                <h3 class="fact-modal__title fact-cascade" id="factModalTitle" style="--cascade-i: 2">Judul Fun Fact</h3>

                <p class="fact-modal__desc fact-cascade" id="factModalDesc" style="--cascade-i: 3"></p>

                <div class="fact-modal__foot fact-cascade" style="--cascade-i: 4">
                    <span class="fact-modal__hint">Tekan <kbd>Esc</kbd> atau klik di luar kartu untuk menutup</span>
                    <button type="button" class="fact-modal__btn" data-close-dialog>Tutup</button>
                </div>
            </div>
        </div>
    </dialog>
</section>
<?php /**PATH E:\Institut Pertanian Bogor\Semester 3\4 - Kamis - Pemrograman Web\Pertemuan 11\pokedex-app\resources\views/pokedex/partials/hero.blade.php ENDPATH**/ ?>