
<span class="type-badges <?php echo e(!empty($iconOnly) ? 'type-badges--icons' : ''); ?>">
    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $key = strtolower(trim($t));
            $meta = config("pokedex.types.{$key}");
            $label = $meta['label'] ?? $t;
            $icon = $meta['icon'] ?? '/images/types/normal.svg';
            $color = $meta['color'] ?? '#888888';
        ?>
        <?php if(!empty($iconOnly)): ?>
            <span class="type-icon-chip" title="<?php echo e($label); ?>" aria-label="<?php echo e($label); ?>">
                <img src="<?php echo e(asset($icon)); ?>" alt="<?php echo e($label); ?>" width="28" height="28" loading="lazy">
            </span>
        <?php else: ?>
            <span class="type-badge <?php echo e(isset($variant) ? 'type-badge--'.$variant : ''); ?>" style="--tc: <?php echo e($color); ?>">
                <img src="<?php echo e(asset($icon)); ?>" alt="" class="type-badge__icon" width="20" height="20" loading="lazy">
                <span><?php echo e($label); ?></span>
            </span>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</span>
<?php /**PATH E:\Institut Pertanian Bogor\Semester 3\4 - Kamis - Pemrograman Web\Pertemuan 11\pokedex-app\resources\views/pokedex/partials/type-badges.blade.php ENDPATH**/ ?>