
<section id="search" class="pokedex section" aria-labelledby="pokedexTitle">
    <div class="pokedex__head">
        <div>
            <p class="section-kicker" data-i18n="pokedex_kicker">Pustaka Pokémon</p>
            <h2 id="pokedexTitle" class="section-title section-title--lg" data-i18n="pokedex_title">Data Master Pokémon</h2>
        </div>
        <p class="pokedex__count" aria-live="polite">Menampilkan <strong id="resultCount"><?php echo e($total); ?></strong> dari <?php echo e($total); ?> Pokémon</p>
    </div>

    <div class="toolbar" role="search">
        <label class="search-field">
            <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6.5" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="m16 16 4.5 4.5" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>
            <span class="visually-hidden">Cari Pokémon</span>
            <input type="search" id="searchInput" placeholder="Cari nama atau nomor index…" autocomplete="off" enterkeyhint="search">
            <kbd aria-hidden="true">/</kbd>
        </label>
        <label class="select-field">
            <span class="visually-hidden">Filter tipe</span>
            <select id="typeFilter">
                <option value="">Semua tipe (<?php echo e(count($typeMeta)); ?>)</option>
                <?php $__currentLoopData = $typeMeta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeKey => $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $tLabel = $meta['label']; ?>
                    <option value="<?php echo e($tLabel); ?>"><?php echo e($tLabel); ?> (<?php echo e($tipeCounts[$tLabel] ?? 0); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </label>
        <label class="select-field">
            <span class="visually-hidden">Filter generasi</span>
            <select id="genFilter">
                <option value="">Semua generasi (Gen I – IX)</option>
                <option value="Generasi I (Kanto)">Generasi I (Kanto)</option>
                <option value="Generasi II (Johto)">Generasi II (Johto)</option>
                <option value="Generasi III (Hoenn)">Generasi III (Hoenn)</option>
                <option value="Generasi IV (Sinnoh)">Generasi IV (Sinnoh)</option>
                <option value="Generasi V (Unova)">Generasi V (Unova)</option>
                <option value="Generasi VI (Kalos)">Generasi VI (Kalos)</option>
                <option value="Generasi VII (Alola)">Generasi VII (Alola)</option>
                <option value="Generasi VIII (Galar)">Generasi VIII (Galar)</option>
                <option value="Generasi IX (Paldea)">Generasi IX (Paldea)</option>
            </select>
        </label>
    </div>

    <div class="table-wrap glass">
        <table class="dex-table dex-table--master">
            <thead>
                <tr>
                    <th scope="col" aria-sort="ascending"><button type="button" data-sort="num"><span data-i18n="th_no_index">Nomor Index</span> <span class="sort-ind" aria-hidden="true"></span></button></th>
                    <th scope="col" aria-sort="none"><button type="button" data-sort="name"><span data-i18n="th_pokemon_name">Nama Pokémon</span> <span class="sort-ind" aria-hidden="true"></span></button></th>
                    <th scope="col" aria-sort="none"><button type="button" data-sort="tipe"><span data-i18n="th_type">Tipe</span> <span class="sort-ind" aria-hidden="true"></span></button></th>
                    <th scope="col" aria-sort="none"><button type="button" data-sort="gen"><span data-i18n="th_generation">Generasi</span> <span class="sort-ind" aria-hidden="true"></span></button></th>
                    <th scope="col" class="col-arrow"><span class="visually-hidden">Aksi</span></th>
                </tr>
            </thead>
            <tbody id="dexBody">
                <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="dex-row" data-no="<?php echo e($p->nomor_index); ?>" data-num="<?php echo e($p->number); ?>"
                        data-name="<?php echo e(strtolower($p->nama_pokemon)); ?>" data-tipe="<?php echo e(strtolower($p->tipe)); ?>"
                        data-types="<?php echo e(strtolower(implode('|', $p->type_list))); ?>" data-gen="<?php echo e($p->generasi); ?>" data-gen-num="<?php echo e($p->gen_number); ?>">
                        <td data-label="Nomor Index">
                            <span class="dex-no">
                                <img src="<?php echo e($p->sprite_url); ?>" alt="" loading="lazy" width="48" height="48">
                                <?php echo e($p->nomor_index); ?>

                            </span>
                        </td>
                        <td data-label="Nama Pokémon">
                            <button type="button" class="row-link" data-open-pokemon="<?php echo e($p->nomor_index); ?>"><?php echo e($p->nama_pokemon); ?></button>
                        </td>
                        <td data-label="Tipe"><?php echo $__env->make('pokedex.partials.type-badges', ['types' => $p->type_list, 'iconOnly' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                        <td data-label="Generasi" class="dex-gen"><?php echo e($p->generasi); ?></td>
                        <td class="col-arrow" aria-hidden="true">
                            <svg aria-hidden="true" viewBox="0 0 24 24"><path d="m9 6 6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        
        <div class="table-empty" id="emptyState" <?php if($total > 0): ?> hidden <?php endif; ?>>
            <img src="<?php echo e(asset('images/pokeball.svg')); ?>" alt="Pokéball" width="56" height="56" style="opacity: 0.65; margin-bottom: 12px; filter: drop-shadow(0 4px 8px rgba(0,0,0,0.4));">
            <p><strong>Belum ada Pokémon.</strong> Import file .xlsx untuk memulai.</p>
            <button type="button" class="action-pill action-pill--primary" data-action="import">Import Excel</button>
        </div>

        
        <div class="table-empty" id="noResult" hidden>
            <p>Tidak ada Pokémon yang cocok dengan <strong id="noResultQuery"></strong>.</p>
            <button type="button" class="action-pill action-pill--ghost" data-reset-filters>Reset filter</button>
        </div>
    </div>

    <nav class="pager" id="pager" aria-label="Halaman tabel"></nav>
</section>
<?php /**PATH E:\Institut Pertanian Bogor\Semester 3\4 - Kamis - Pemrograman Web\Pertemuan 999\src\resources\views/pokedex/partials/table.blade.php ENDPATH**/ ?>